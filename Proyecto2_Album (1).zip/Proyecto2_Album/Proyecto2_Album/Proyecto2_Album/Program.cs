﻿using System;
using System.Threading;

namespace Proyecto2_Album
{
    class Program
    {
        static Album album;
        static void marcarEstampa(string codigo)
        {
            int i = album.buscarEstampa(codigo);
            if(i >= 0)
            {
                album.estampas[i].marcar();
            }
            else
            {
                Console.WriteLine("Estampa no encontrada");
            }
        }
        static void Main(string[] args)
        {
            
            string estampa_ingresada;
            string opcion;
            int menu;
            do
            {
                Console.WriteLine("Bienvenido al proyecto");
                Console.WriteLine("Ingrese las estampas que tiene");
                estampa_ingresada = Console.ReadLine();
                Console.WriteLine("Desea ingresar otra estampa? (Ingrese s/n)");
                Console.WriteLine("Ingrese las estampas con las 3 letras en mayusculas, junto con su número. Ejemplo: FWC3");
                opcion = Console.ReadLine();
            }
            while (opcion == "s" || opcion == "S");
            Console.Clear();
            album = new Album();
            Console.WriteLine("PROYECTO NO.2");
            Console.WriteLine("Album mundial");
            Console.WriteLine("Bienvenido al menu inicial, ingrese la opcion que desea");
            Console.WriteLine("1. Ver estampas faltantes");
            Console.WriteLine("2. Ver estampas repetidas");
            Console.WriteLine("3. Ver nuestras estampas");
            Console.WriteLine("4. Salir");
         
            menu = int.Parse(Console.ReadLine());
            Console.Clear();
            switch(menu)
            {
                case 1:
                    album.mostrarFaltantes();
                    Console.ReadKey();
                    break;
                    case 2:
                    album.mostrarRepetidas();
                    Console.ReadKey();  
                    break;
                case 3:
                    album.mostrarMarcadas();
                    Console.ReadKey();
                    break;
                case 4:
                    break;

            }
        }
    }
}
